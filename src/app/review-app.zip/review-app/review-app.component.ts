import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-review-app',
  templateUrl: './review-app.component.html',
  styleUrls: ['./review-app.component.css']
})
export class ReviewAppComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
